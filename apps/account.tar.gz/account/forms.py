import datetime
from django import forms
from django.core.urlresolvers import reverse
from django.contrib.auth import get_user_model
User = get_user_model()

from apps.account.models import EmailVerification
from apps.common import generate_random_string, get_current_site



class UserForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'email', 'username', 'password', 'gender', 'country']
        widgets = {
            'password': forms.PasswordInput(),
        }

    def save(self, commit=True):
        # Save the provided password in hashed format
        user = super(UserForm, self).save(commit=False)
        user.set_password(self.cleaned_data["password"])
        if commit:
            user.save()

        verification = EmailVerification(
            user=user,
            token=generate_random_string(32),
            created_on=datetime.datetime.now()
        )
        verification.save()

        user.email_user('Verify', 'http://%s%s' % (get_current_site().domain, reverse('verify', kwargs={'token': verification.token})))
        return user

class UserEditProfileForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ["first_name", "last_name", "email"]

# class CompanyAddressForm(forms.Form):
#     area = forms.CharField()
#     street = forms.CharField()
#     city = forms.CharField()
#     state = forms.CharField()
#     country = forms.CharField()
#     zipcode = forms.CharField()
#
# class CompanyDetailForm(forms.Form):
#     description = forms.CharField(widget=forms.Textarea)
#     add_more_detail = forms.CharField(widget=forms.Textarea)
#     add_cover_image = forms.FileInput()
#     add_portfolio   = forms.FileInput()
#     add_link = forms.CharField()
#     social_profile = forms.ChoiceField(choices = SOCIAL_PROFILE)
#     company_url = forms.CharField()
#
# class AcceptInviteForm(forms.Form):
#     first_name = forms.CharField()
#     last_name = forms.CharField()
#     designation = forms.CharField()
#     password = forms.CharField()
#
# class AddProductsForm(forms.Form):
#     product_catalog = forms.FileField()
#     showcase_option = forms.ChoiceField(choices=SHOWCASE)
#     product_video = forms.FileField()
#     embed_src = forms.CharField()
#
# class AddServicesForm(forms.Form):
#     client_portfolio = forms.CharField()
#     services_offered = forms.CharField(widget=forms.Textarea)
#     description = forms.CharField(widget=forms.Textarea)
#
# class AddPortfolioForm(forms.Form):
#     name = forms.CharField()
#     client_logo = forms.ImageField()
#     description = forms.CharField(widget=forms.Textarea)


