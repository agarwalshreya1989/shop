from django.conf.urls import patterns, include, url

from apps.account.views import RegistrationView, VerifyView, UserEditProfileView, RegistrationDoneView,WelcomeView

urlpatterns = patterns('',
    url(r'^register/$', RegistrationView.as_view(), name="register"),
    url(r'^verify/(?P<token>[^/]+)/$', VerifyView.as_view(), name="verify"),

    url(r'^login/$', 'django.contrib.auth.views.login', {
        'template_name': 'account/login.html',
        'redirect_field_name': 'next'
        }, name="login"),

    url(r'^logout/$', 'django.contrib.auth.views.logout', {
        'next_page': '/',
        }, name="logout"),
    
    url(r'^edit/(?P<user_id>\d+)/$', UserEditProfileView.as_view(), name="profile"),
    url(r'^', WelcomeView.as_view(), name="welcome"),
    url(r'^registration-done/$', RegistrationDoneView.as_view(), name="done"),

#     url(r'^account/$', AccountView.as_view(), name="account"),
#     url(r'^dashboard/(?P<pk>\d+)/$', DashBoardView.as_view(), name="dashboard"),
#     url(r'^home/$', HomeView.as_view(), name="home"),
#     url(r'^about_us/$', AboutUsView.as_view(), name="about"),
#     url(r'^management/$', ManagementView.as_view(), name="management"),
#     url(r'^contact/$', ContactView.as_view(), name="contact"),
#     url(r'^career/$', CareerView.as_view(), name="career"),
#     url(r'^entrepreneur/$', EntrepreneurView.as_view(), name="entrepreneur"),
#     url(r'^investor/$', InvestorView.as_view(), name="investor"),
#     url(r'^manager/$', ManagerView.as_view(), name="manager"),
)
