
from django.shortcuts import redirect, get_object_or_404
from django.http import HttpResponse, HttpResponseRedirect
from django.views.generic import TemplateView, CreateView, UpdateView, ListView

from django.core.urlresolvers import reverse
from django.shortcuts import get_object_or_404
from django.contrib.auth import get_user_model
from apps.account.models import EmailVerification
from apps.account.forms import UserForm, UserEditProfileForm

User = get_user_model()

class WelcomeView(TemplateView):
    template_name = 'account/base.html'

class RegistrationView(CreateView):
    template_name = "account/registration.html"
    form_class = UserForm

    def form_valid(self, form):
        # creating user in the save() model of the form , args=(user.pk, )
        user = form.save()
        self.template_name = 'account/registration_done.html'
        #return super(RegistrationView, self).form_valid(form)
        return redirect("done")
        

class RegistrationDoneView(TemplateView):
    template_name = "account/registration_done.html"


class VerifyView(TemplateView):
    template_name = 'account/profile.html'

    def get_context_data(self, **kwargs):
        context = super(VerifyView, self).get_context_data(**kwargs)
        token = kwargs.get('token')
        try:
            verification = EmailVerification.objects.get(token=token)
            user = verification.user
            user.is_active = True
            user.save()
            verification.delete()
        except EmailVerification.DoesNotExist:
            self.template_name = 'account/verification_fail.html'
        return context


class UserEditProfileView(UpdateView):
    template_name = "account/edit_profile.html"
    model = User
    form_class = UserEditProfileForm
    
    def get_object(self, **kwargs):
        return get_object_or_404(User, pk=self.kwargs['user_id'])
    
    def form_valid(self, form):
        form.save()
        return redirect(reverse('thank'))

# class AccountView(TemplateView):
#     template_name = "account_base.html"
# 
# 
# class DashBoardView(TemplateView):
#     template_name = "account/dashboard.html"
#     
# 
# class HomeView(TemplateView):
#     template_name = "about/home.html"
# 
# 
# class AboutUsView(TemplateView):
#     template_name = "about/about_us.html"
# 
# 
# class ManagementView(TemplateView):
#     template_name = "about/management.html"
# 
# 
# class ContactView(TemplateView):
#     template_name = "about/contact_us.html"
# 
# 
# class CareerView(TemplateView):
#     template_name = "about/career.html"
# 
# 
# class EntrepreneurView(TemplateView):
#     template_name = "about/entrepreneur.html"
# 
# 
# class InvestorView(TemplateView):
#     template_name = "about/investor.html"
# 
# 
# class ManagerView(TemplateView):
#     template_name = "about/group_manager.html"
